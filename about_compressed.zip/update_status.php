<?php
// update_status.php
header("Content-Type: application/json");

// Get JSON input from JavaScript
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['orderId']) || !isset($data['newStatus'])) {
  echo json_encode(["success" => false, "message" => "Invalid data"]);
  exit();
}

$orderId = $data['orderId'];
$newStatus = $data['newStatus'];

// Load current orders
$ordersFile = "orders.json";
$orders = json_decode(file_get_contents($ordersFile), true);

// Find and update the order status
foreach ($orders as &$order) {
  if ($order['orderId'] === $orderId) {
    $order['status'] = $newStatus;
    break;
}

// Save updated orders
file_put_contents($ordersFile, json_encode($orders, JSON_PRETTY_PRINT));

echo json_encode(["success" => true]);
?>


