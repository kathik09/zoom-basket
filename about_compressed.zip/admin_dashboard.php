<?php
session_start();
if (!isset($_SESSION["admin_logged_in"])) {
  header("Location: admin_login.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Admin Dashboard - Zoom Basket</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <style>
    body { background-color: #f9f9f9; }
    .order-card { background: #fff; padding: 20px; border-radius: 12px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
    .search-bar { margin-bottom: 20px; }
    .summary-card { background: #fff; padding: 15px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); margin-bottom: 20px; }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Zoom Basket Admin</a>
    <a href="admin_logout.php" class="btn btn-light">Logout</a>
  </div>
</nav>

<div class="container mt-4">
  <h2 class="mb-3">📦 Order Management</h2>

  <!-- 🧮 Analytics Summary -->
  <div class="row text-center mb-4">
    <div class="col-md-3"><div class="summary-card"><h5>Total Orders</h5><div id="totalOrders">0</div></div></div>
    <div class="col-md-3"><div class="summary-card"><h5>Total Sales</h5><div id="totalSales">₹0</div></div></div>
    <div class="col-md-3"><div class="summary-card"><h5>Pending</h5><div id="pendingCount">0</div></div></div>
    <div class="col-md-3"><div class="summary-card"><h5>Delivered</h5><div id="deliveredCount">0</div></div></div>
  </div>

  <!-- 🔍 Search -->
  <div class="row search-bar">
    <div class="col-md-6 mx-auto">
      <input type="text" class="form-control" id="searchInput" placeholder="Search by name, ID or date (DD-MM-YYYY)">
    </div>
  </div>

  <!-- 🧾 Orders -->
  <div id="order-container"></div>

  <!-- 🔢 Pagination -->
  <div class="text-center">
    <button id="prevBtn" class="btn btn-secondary me-2" disabled>Previous</button>
    <button id="nextBtn" class="btn btn-secondary">Next</button>
  </div>
</div>

<!-- 📋 Modal for Order Details -->
<div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Order Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modalBody"></div>
    </div>
  </div>
</div>

<script>
let orders = [];
let currentPage = 1;
const perPage = 5;

async function fetchOrders() {
  const res = await fetch("orders.json");
  orders = await res.json();
  orders.reverse();
  updateAnalytics();
  renderOrders();
}

function renderOrders() {
  const search = document.getElementById("searchInput").value.toLowerCase();
  const filtered = orders.filter(order =>
    order.customer.fullName.toLowerCase().includes(search) ||
    order.orderId.toLowerCase().includes(search) ||
    order.orderDate.toLowerCase().includes(search)
  );

  const start = (currentPage - 1) * perPage;
  const paginated = filtered.slice(start, start + perPage);

  const container = document.getElementById("order-container");
  container.innerHTML = paginated.length === 0
    ? "<p>No orders found.</p>"
    : paginated.map(order => {
      const statusOptions = ["Pending", "Out for Delivery", "Delivered"]
        .map(status => `<option ${order.status === status ? 'selected' : ''}>${status}</option>`).join("");

      return `
        <div class="order-card">
          <h5>Order #${order.orderId} <span class="text-muted float-end">${order.orderDate}</span></h5>
          <p><strong>${order.customer.fullName}</strong> (${order.customer.phone})</p>
          <p>₹${order.total} | ${order.customer.paymentMethod}</p>
          <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
            <select class="form-select w-auto" onchange="updateStatus('${order.orderId}', this.value)">
              ${statusOptions}
            </select>
            <button class="btn btn-outline-success btn-sm" onclick="approveOrder('${order.orderId}')">✅ Approve</button>
            <button class="btn btn-outline-info btn-sm" onclick="alert('📞 Call: ${order.customer.phone}')">📞 Contact</button>
            <button class="btn btn-outline-primary btn-sm" onclick="showDetails(${JSON.stringify(order).replace(/"/g, '&quot;')})">🔍 View Details</button>
          </div>
        </div>`;
    }).join("");

  document.getElementById("prevBtn").disabled = currentPage === 1;
  document.getElementById("nextBtn").disabled = start + perPage >= filtered.length;
}

function updateStatus(orderId, newStatus) {
  fetch('update_status.php', {
    method: 'POST',
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ orderId, newStatus })
  })
  .then(res => res.json())
  .then(data => {
    if (data.success) fetchOrders();
    else alert("❌ Failed to update");
  });
}

function approveOrder(orderId) {
  updateStatus(orderId, "Out for Delivery");
  alert("✅ Customer notified: Your order is on process - delivery soon!");
}

function showDetails(order) {
  const itemsHTML = order.cart.map(item => `
    <li>${item.name} x ${item.quantity} = ₹${item.quantity * item.price}</li>
  `).join("");
  const modalHTML = `
    <p><strong>Order ID:</strong> ${order.orderId}</p>
    <p><strong>Date:</strong> ${order.orderDate}</p>
    <p><strong>Name:</strong> ${order.customer.fullName}</p>
    <p><strong>Email:</strong> ${order.customer.email}</p>
    <p><strong>Phone:</strong> ${order.customer.phone}</p>
    <p><strong>Address:</strong> ${order.customer.address}, ${order.customer.city} - ${order.customer.pincode}</p>
    <p><strong>Payment Method:</strong> ${order.customer.paymentMethod}</p>
    <p><strong>Total:</strong> ₹${order.total}</p>
    <h6>Items Ordered:</h6><ul>${itemsHTML}</ul>
    <p><strong>Status:</strong> ${order.status}</p>
  `;
  document.getElementById("modalBody").innerHTML = modalHTML;
  const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
  modal.show();
}

function updateAnalytics() {
  document.getElementById("totalOrders").textContent = orders.length;
  document.getElementById("totalSales").textContent = "₹" + orders.reduce((sum, o) => sum + o.total, 0);
  document.getElementById("pendingCount").textContent = orders.filter(o => o.status === "Pending").length;
  document.getElementById("deliveredCount").textContent = orders.filter(o => o.status === "Delivered").length;
}

document.getElementById("searchInput").addEventListener("input", () => {
  currentPage = 1;
  renderOrders();
});
document.getElementById("prevBtn").addEventListener("click", () => { if (currentPage > 1) { currentPage--; renderOrders(); } });
document.getElementById("nextBtn").addEventListener("click", () => { currentPage++; renderOrders(); });

fetchOrders();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





