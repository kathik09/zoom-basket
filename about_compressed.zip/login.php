<?php
session_start();
include "db_conn.php";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['email']) && isset($_POST['password'])) {
  $email = trim($_POST['email']);
  $password = $_POST['password'];

  // Check user in DB by email
  $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
  $stmt->bind_param("s", $email);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result && $result->num_rows === 1) {
    $row = $result->fetch_assoc();
    
    if (password_verify($password, $row['password'])) {
      $_SESSION['username'] = $row['fullname']; // You can also use email here
      header("Location: index.php");
      exit();
    } else {
      echo "<p style='color:red;'>❌ Wrong password</p>";
    }
  } else {
    echo "<p style='color:red;'>❌ User not found</p>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login - Zoom Basket</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link rel="stylesheet" href="style.css" />
</head>
<body class="login-page">
  <div class="login-box">
    <h2 class="text-center mb-4 fw-bold">Login</h2>
    <form action="login.php" method="POST">
      <div class="mb-3">
        <label for="loginEmail" class="form-label">Email address</label>
        <input type="email" class="form-control" id="loginEmail" name="email" placeholder="Enter email" required />
      </div>

      <div class="mb-3">
        <label for="loginPassword" class="form-label">Password</label>
        <input type="password" class="form-control" id="loginPassword" name="password" placeholder="Password" required />
      </div>

      <button type="submit" class="btn btn-primary w-100">Login</button>

      <div class="mt-3 text-center">
        Don't have an account? <a href="register.html">Register</a>
        <div class="text-center mt-3">
          <a href="index.html" class="btn btn-secondary">← Back to Home</a>
        </div>
      </div>
    </form>
  </div>

</body>
</html>


