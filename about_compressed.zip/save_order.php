<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);
$file = 'orders.json';

if ($data) {
    $orders = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    if (!is_array($orders)) {
        $orders = [];
    }

    $orders[] = $data;

    if (file_put_contents($file, json_encode($orders, JSON_PRETTY_PRINT))) {
        // Assign $order for convenience
        $order = $data;

        // Send confirmation email (optional)
        $to = filter_var($order['customer']['email'], FILTER_VALIDATE_EMAIL);
        if ($to) {
            $subject = "Your Zoom Basket Order Confirmation - " . htmlspecialchars($order['orderId']);
            $message = "Hello " . htmlspecialchars($order['customer']['fullName']) . ",\n\n";
            $message .= "Thank you for your order at Zoom Basket!\n";
            $message .= "Order ID: " . htmlspecialchars($order['orderId']) . "\n";
            $message .= "Total: ₹" . number_format($order['total'], 2) . "\n\n";
            $message .= "We'll deliver your items soon. ❤️";

            $headers = "From: no-reply@zoombasket.com";

            @mail($to, $subject, $message, $headers);
        }

        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Failed to save orders file"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "No data received"]);
}







