<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $data = json_decode(file_get_contents("php://input"), true);
  $orderId = $data["orderId"];
  $newStatus = $data["newStatus"];

  $orders = json_decode(file_get_contents("orders.json"), true);

  foreach ($orders as &$order) {
    if ($order["orderId"] === $orderId) {
      $order["status"] = $newStatus;
      break;
    }
  }

  file_put_contents("orders.json", json_encode($orders, JSON_PRETTY_PRINT));
  echo json_encode(["success" => true]);
}
?>
