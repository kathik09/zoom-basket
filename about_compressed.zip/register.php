<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "zoombasket";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Only run when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {

  // Get and sanitize inputs
  $fullname = trim($_POST['fullname']);
  $email = trim($_POST['email']);
  $password = $_POST['password'];
  $confirm_password = $_POST['confirm_password'];

  // Basic validation
  if (empty($fullname) || empty($email) || empty($password) || empty($confirm_password)) {
    echo "<p style='color:red;'>All fields are required.</p>";
    exit();
  }

  if ($password !== $confirm_password) {
    echo "<p style='color:red;'>Passwords do not match.</p>";
    exit();
  }

  // Check if email already exists
  $check = $conn->prepare("SELECT * FROM users WHERE email = ?");
  $check->bind_param("s", $email);
  $check->execute();
  $result = $check->get_result();
  if ($result->num_rows > 0) {
    echo "<p style='color:red;'>❌ This email is already registered. Please login instead.</p>";
    exit();
  }

  // Hash the password
  $hashed_password = password_hash($password, PASSWORD_DEFAULT);

  // Save to DB
  $sql = "INSERT INTO users (fullname, email, password) VALUES (?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("sss", $fullname, $email, $hashed_password);

  if ($stmt->execute()) {
    header("Location: login.php");
    exit();
  } else {
    echo "<p style='color:red;'>Something went wrong. Please try again later.</p>";
  }
}
?>







