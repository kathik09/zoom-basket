<?php
session_start();
session_destroy(); // Clear session data
header("Location: admin_login.php"); // Redirect to login page
exit();
