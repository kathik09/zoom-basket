document.addEventListener("DOMContentLoaded", () => {
  // Redirect for Sign In
  const signInButton = document.getElementById("signinBtn");
  if (signInButton) {
    signInButton.addEventListener("click", () => {
      window.location.href = "login.html";
    });
  }

  // Initialize cart from localStorage
  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  // Handle Add to Cart buttons
  const addToCartButtons = document.querySelectorAll('.add-to-cart');
  addToCartButtons.forEach(button => {
    button.addEventListener('click', () => {
      const name = button.getAttribute('data-name');
      const price = parseFloat(button.getAttribute('data-price'));
      const image = button.getAttribute('data-image');

      // Check if item already in cart
      const existingItem = cart.find(item => item.name === name);
      if (existingItem) {
        existingItem.quantity += 1;
      } else {
        cart.push({ name, price, image, quantity: 1 });
      }

      localStorage.setItem('cart', JSON.stringify(cart));
      updateCartCount();
      showToast(`${name} added to cart`);
    });
  });

  // Update cart count on page load
  updateCartCount();

  // Populate cart page if on cart.html
  const cartItemsContainer = document.getElementById('cart-items');
  const totalPriceElement = document.getElementById('total-price');
  const emptyCartMessage = document.getElementById('empty-cart-message');

  if (cartItemsContainer && totalPriceElement) {
    if (cart.length === 0 && emptyCartMessage) {
      emptyCartMessage.style.display = 'block';
    } else {
      let total = 0;

      cart.forEach(item => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';

        card.innerHTML = `
          <div class="card">
            <img src="${item.image}" class="card-img-top" alt="${item.name}">
            <div class="card-body">
              <h5 class="card-title">${item.name}</h5>
              <p class="card-text">Price: ₹${item.price}</p>
              <p class="card-text">Quantity: ${item.quantity}</p>
            </div>
          </div>
        `;

        total += item.price * item.quantity;
        cartItemsContainer.appendChild(card);
      });

      totalPriceElement.textContent = total.toFixed(2);
    }
  }
});

// Helper: Update cart count badge
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const badge = document.getElementById('cart-count');
  if (badge) badge.textContent = count;
}

// Helper: Show toast notification
function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, 2000);
}


document.addEventListener("DOMContentLoaded", () => {
  const cartItemsContainer = document.getElementById('cart-items');
  const totalPriceElement = document.getElementById('total-price');

  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  function renderCart() {
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach((item, index) => {
      const card = document.createElement('div');
      card.className = 'col-md-4 mb-4';

      card.innerHTML = `
        <div class="card h-100">
          <img src="${item.image}" class="card-img-top" alt="${item.name}">
          <div class="card-body">
            <h5 class="card-title">${item.name}</h5>
            <p class="card-text">Price: ₹${item.price}</p>
            <div class="d-flex align-items-center mb-2">
              <button class="btn btn-sm btn-outline-secondary me-2 quantity-btn" data-index="${index}" data-action="decrease">−</button>
              <span id="qty-${index}" class="mx-2">${item.quantity}</span>
              <button class="btn btn-sm btn-outline-secondary ms-2 quantity-btn" data-index="${index}" data-action="increase">+</button>
            </div>
            <button class="btn btn-danger btn-sm remove-btn" data-index="${index}">Remove</button>
          </div>
        </div>
      `;

      total += item.price * item.quantity;
      cartItemsContainer.appendChild(card);
    });

    totalPriceElement.textContent = total.toFixed(2);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
  }

  // Handle quantity change and remove
  cartItemsContainer.addEventListener('click', (e) => {
    const index = e.target.getAttribute('data-index');

    if (e.target.classList.contains('quantity-btn')) {
      const action = e.target.getAttribute('data-action');
      if (action === 'increase') {
        cart[index].quantity += 1;
      } else if (action === 'decrease' && cart[index].quantity > 1) {
        cart[index].quantity -= 1;
      }
      renderCart();
    }

    if (e.target.classList.contains('remove-btn')) {
      cart.splice(index, 1);
      renderCart();
    }
  });

  renderCart(); // Initial render
});

// Reuse these helper functions
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const badge = document.getElementById('cart-count');
  if (badge) badge.textContent = count;
}

function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;

  toast.textContent = message;
  toast.classList.add('show');

  setTimeout(() => {
    toast.classList.remove('show');
  }, 2000);
}


    // Populate order summary
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const summaryDiv = document.getElementById('cart-summary');
    let total = 0;

    if (cart.length === 0) {
      summaryDiv.innerHTML = "<p>Your cart is empty.</p>";
    } else {
      cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        summaryDiv.innerHTML += `
          <div class="d-flex justify-content-between border-bottom py-2">
            <div>
              <strong>${item.name}</strong><br>
              <small>Qty: ${item.quantity}</small>
            </div>
            <div>₹${(itemTotal).toFixed(2)}</div>
          </div>
        `;
      });
      summaryDiv.innerHTML += `
        <div class="d-flex justify-content-between pt-3">
          <strong>Total:</strong>
          <strong>₹${total.toFixed(2)}</strong>
        </div>
      `;
    }

    // Handle form submission
    document.getElementById("checkout-form").addEventListener("submit", function (e) {
      e.preventDefault();
      alert("Order placed successfully!");
      localStorage.removeItem("cart");
      window.location.href = "index.html";
    });



    // Store bill details
const billDetails = {
  name: document.getElementById("fullName").value,
  address: document.getElementById("address").value,
  city: document.getElementById("city").value,
  paymentMethod: document.getElementById("paymentMethod").value,
  cart: JSON.parse(localStorage.getItem("cart")) || [],
};
localStorage.setItem("billDetails", JSON.stringify(billDetails));

// Clear cart
localStorage.removeItem("cart");

// Redirect
window.location.href = "thankyou.html";





