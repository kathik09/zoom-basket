<?php
session_start();
$isLoggedIn = isset($_SESSION['username']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ZOOM BASKET</title>
  <link rel="stylesheet" href="style.css" />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
</head>
<body>

  <!-- NAVBAR -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">ZOOM BASKET</a>
      <button class="navbar-toggler" type="button"
              data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-between" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
          <li class="nav-item"><a class="nav-link" href="#products">Products</a></li>
          <li class="nav-item"><a class="nav-link" href="#about">About</a></li>
          <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
        </ul>


        <!-- CART & SIGN IN -->
        <div class="d-flex align-items-center gap-2">
          <a href="cart.html" class="btn btn-danger btn-sm position-relative">
            🛒
            <span id="cart-count" class="badge bg-warning text-dark">0</span>

          </a>
          <?php if ($isLoggedIn): ?>
  <span class="text-white">Welcome, <?php echo $_SESSION['username']; ?></span>
  <a href="logout.php" class="btn btn-warning btn-sm">Sign out</a>
<?php else: ?>
  <a href="login.php" class="btn btn-success btn-sm">Sign in</a>
<?php endif; ?>


        </div>
      </div>
    </div>
  </nav>

  <!-- HOME -->
  <section id="home" class="text-center py-5 bg-light">
    <h1>GOODS & GROCERIES</h1>
    <p>Fresh, Fast and Full of Goodness</p>
    <!-- BELOW IS OPTIONAL ADDITIONAL SEARCH (if you want one here too) -->
       

  </section>

  <!-- PRODUCTS -->
  <section id="products" class="py-5">
    <div class="container">
      <h1 class="text-center mb-5" style="color:#29f700;">PRODUCTS</h1>
      <div class="row g-4" id="productsContainer">
        <!-- Produce -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="produce">
          <div class="card">
            <img src="img 1.png.jpg" class="card-img-top" alt="Produce">
            <div class="card-body text-center">
              <h5 class="card-title">Produce</h5>
              <a href="produce.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Dairy -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="dairy products">
          <div class="card">
            <img src="img 2.jpg" class="card-img-top" alt="Dairy Products">
            <div class="card-body text-center">
              <h5 class="card-title">Dairy Products</h5>
              <a href="dairy.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Dry Fish -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="dry fish">
          <div class="card">
            <img src="img 3.jpg" class="card-img-top" alt="Dry Fish">
            <div class="card-body text-center">
              <h5 class="card-title">Dry Fish</h5>
              <a href="dryfish.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Bakery -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="bakery products">
          <div class="card">
            <img src="img 4.jpg" class="card-img-top" alt="Bakery Products">
            <div class="card-body text-center">
              <h5 class="card-title">Bakery Products</h5>
              <a href="bakery.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Pantry -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="pantry staples">
          <div class="card">
            <img src="img 5.png" class="card-img-top" alt="Pantry Staples">
            <div class="card-body text-center">
              <h5 class="card-title">Pantry Staples</h5>
              <a href="pantry.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Beverages -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="beverages">
          <div class="card">
            <img src="img 6.jpg" class="card-img-top" alt="Beverages">
            <div class="card-body text-center">
              <h5 class="card-title">Beverages</h5>
              <a href="beverages.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Snacks -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="snacks & confectionery">
          <div class="card">
            <img src="img 7.jpg" class="card-img-top" alt="Snacks & Confectionery">
            <div class="card-body text-center">
              <h5 class="card-title">Snacks & Confectionery</h5>
              <a href="snacks.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Health & Beauty -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="health and beauty">
          <div class="card">
            <img src="img 8.jpg" class="card-img-top" alt="Health & Beauty">
            <div class="card-body text-center">
              <h5 class="card-title">Health & Beauty</h5>
              <a href="beauty.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>
        <!-- Household Items -->
        <div class="col-lg-4 col-md-6 col-sm-12 product" data-name="household items">
          <div class="card">
            <img src="img 9.jpg" class="card-img-top" alt="Household Items">
            <div class="card-body text-center">
              <h5 class="card-title">Household Items</h5>
              <a href="household.html" class="btn btn-success">Show</a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </section>


  <!-- ABOUT -->
  <section id="about" >
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6 col-md-6 col-12">
        <img src="about.png" class="img-fluid" alt="About Us">
      </div>
      <div class="col-lg-6 col-md-6 col-12 p-lg-5 p-2">
        <h1 class="text-center">About Us</h1>
        <p>We are a proud family-owned business committed to delivering the highest quality groceries and everyday essentials right to your doorstep. At ZOOM BASKET, we believe that fresh, healthy, and affordable food should be accessible to everyone — and we work tirelessly to make that vision a reality.<br>
        We partner with local farms, bakeries, and trusted suppliers to ensure that every item we offer — from crisp vegetables and dairy products to pantry staples and household necessities — meets our high standards of freshness, safety, and value. Our team constantly updates the catalog to bring you seasonal favorites, new arrivals, and must-have essentials.<br>
      Above all, we cherish the trust our customers place in us and strive to build lasting relationships. We're more than just a store — we're your neighbors, your partners in meal planning, and your go-to for all things grocery.</p>
      </div>
      </div>
    </div>
  </section>

  <!-- CONTACT -->
  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 col-md-6 col-12">
        </div>
        <div class="col-lg-6 col-md-6 col-12 p-lg-5 p-2">
    <h1 class="text-center">Contact Us</h1>
    <form>
      <input type="text" class="form-control mb-3" placeholder="Your Name" required>
      <input type="email" class="form-control mb-3" placeholder="Your Email" required>
      <textarea class="form-control mb-3" placeholder="Your Message" required></textarea>
      <button class="btn btn-primary">Send</button>
    </form>
    <h1 class="text-center">Get in Touch</h1>
          <p>Have questions, feedback, or need assistance? We're here to help! Reach out to us through any of the following channels:</p>
          <ul>
  </section>

  <footer class="text-center py-3 bg-dark text-white">
    Copyrights © ZoomBasket 2025
  </footer>

  <!-- Link to your external JS -->
  <script src="script.js" defer></script>
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    defer
  ></script>
</body>
</html>





